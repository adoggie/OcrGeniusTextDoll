//
// Created by zhangwenming02.
//
#pragma once

#include <string>
#include <vector>
#include <map>
#include "opencv2/core/core.hpp"
#include "ocrgeneralocr_status.h"
#include "ocrgeneralocr_response.h"
#include "DLL_API.h"

namespace pv_ocrgeneralocr {

class OcrdetectAbility;
class RecognizeAbility;

class OcrgeneralocrEngine{
public:
    DLL_API OcrgeneralocrEngine();

    DLL_API ~OcrgeneralocrEngine();

    DLL_API PVStatus init(std::string model_path, int thread_num, int power_mode);

    DLL_API PVStatus uninit();

    // 推荐使用接口
    DLL_API PVStatus process(cv::Mat &src_img, int lang_type, std::vector<PVResponse>& result);

private:
    OcrdetectAbility *ocrdetect_ability;
    RecognizeAbility *recognize_ability;
};

}

//#endif //OCRDEMO_EASY_MOBILE_OCR_H
