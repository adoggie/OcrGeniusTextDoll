//
// Created by zhangwenming02.
//
#pragma once

namespace pv_ocrgeneralocr {

typedef enum PVStatus {
    SUCCESS = 0,                       // 成功
    NOT_AUTHORIZED = 1,                // 未授权
    MODEL_DECRYPT_ERROR = 2,           // 模型解密错误
    NN_LOAD_FAILED = 3,                // 预测库对象未失败
    PARAM_IMAGE_ERROR = 4,             // 图像参数异常，size为0，或者非BGR类型图片
    NN_PREDICT_ERROR = 5,              // 预测库对象初始化失败
    PARAM_ERROR = 6,                   // 参数异常
    INIT_PROCEDURE_ERROR = 7,          // 初始化步骤错误
    OTHER_ERROR = -65535               // 未知错误
} PVStatus;

} // namespace pv_ocrgeneralocr
