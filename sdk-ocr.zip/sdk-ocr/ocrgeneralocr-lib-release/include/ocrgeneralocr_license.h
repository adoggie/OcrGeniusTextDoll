/***************************************************************************
*
* Copyright (c) 2019 Baidu.com, Inc. All Rights Reserved
*
**************************************************************************/

/**
 * @file    ibdocrgeneralocr_license.h
 * @author  zhangwenming02@baidu.com
 * @date    2019/01/28 14:32:57
 * @brief   授权接口文件
 *
 **/

#pragma once

#include <vector>
#include "DLL_API.h"
#include "bd_license_defs.h"

#ifdef __cplusplus
namespace pv_ocrgeneralocr {
// extern "C" {
#endif

/*
* @brief 本地文件鉴权，license_folder下需要存在license.key, license.ini文件
* @param const std::string& license_folder: 授权文件读写路径
* @param bool is_remote: 是否允许联网更新本地授权文件
* @param int algorithm_id: 算法(业务ID)
*/
DLL_API vis_license::ErrorCode powervision_auth_from_folder(
    const std::string& license_folder,
    bool is_remote);

/**
 * @brief   从授权文件读取授权信息进行授权
 * @param[in]   const std::string&      license_key     license key
 * @param[in]   const std::string&      license_path    授权文件路径
 * @param[in]   bool                    is_remote       是否允许网络授权
 * @return      vis_license::ErrorCode  状态码
 */
DLL_API vis_license::ErrorCode powervision_auth_from_file(
        const std::string& license_key,
        const std::string& license_path,
        bool is_remote);

/**
 * @brief   从内存中读取授权信息进行授权
 * @param[in]   const std::string&              license_key     license key
 * @param[in]   const std::vector<std::string>  license_str     license信息
 * @param[in]   const std::string&              license_path
 * @return      vis_license::ErrorCode          状态码
 */
DLL_API vis_license::ErrorCode powervision_auth_from_memory(
        const std::string& license_key,
        const std::vector<std::string>& license_str,
        const std::string& license_path);

/**
 * @brief   获取本地授权信息
 * @return  vis_license::BDLicenseLocalInfo     授权信息
 */
DLL_API vis_license::BDLicenseLocalInfo powervision_auth_get_local_info();

/**
 * @brief   获取授权日志信息
 * @return  std::string     授权日志
 */
DLL_API std::string powervision_auth_get_error_msg();

/**
 * @brief   获取授权状态
 * @return  vis_license::ErrorCode  状态码
 */
vis_license::ErrorCode powervision_auth_get_status();

/**
 * @brief   获取指定功能的授权状态
 * @param[in]   std::string             func_name   功能名称
 * @return      vis_license::ErrorCode  状态码
 */
vis_license::ErrorCode powervision_auth_is_func_available(std::string func_name);

/**
 * 获取业务对应算法ID
 * @return 算法ID
 */
int powervision_auth_get_algorithm_id();

#ifdef __cplusplus
// }
}// namespace easy_mobile_util
#endif
