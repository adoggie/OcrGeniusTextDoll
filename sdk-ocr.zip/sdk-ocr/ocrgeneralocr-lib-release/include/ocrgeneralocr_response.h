//
// Created by zhangwenming02.
//
#pragma once

#include <string>

namespace pv_ocrgeneralocr {

typedef struct PVResponse {
    int x1;
    int y1;
    int x2;
    int y2;
    int x3;
    int y3;
    int x4;
    int y4;
    float left;
    float top;
    float width;
    float height;
    float score;
    std::string result;
}PVResponse;

} //namespace pv_ocrgeneralocr
